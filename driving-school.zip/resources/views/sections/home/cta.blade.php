<div class="col-sm-12 bg-dark">
    <div class="tt-description" style="padding:48px">
        <h2 class="tt-title content_typography">Schedule <span>Your Driving Lessons</span> with Us!</h2>
        <div>
            <p>Book our taster lesson and meet your personal driving instructor</p>						
        </div>
        <address>800-123-4567</address>
        <img decoding="async" class="tt-icon" src="https://smartdata.tonytemplates.com/dricub-driving-school/wp-content/uploads 2017/10/tt-promo-03-icon.png" alt="icon">					
    </div>
</div>