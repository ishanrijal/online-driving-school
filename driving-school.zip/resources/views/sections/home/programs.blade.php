<div class="col-sm-8 section-head" style="padding: 48px 0 0 0">
    <h2 style="text-align: center; font-weight:700">Our Programs</h2>
</div>
<div class="col-sm-10" style="margin: 40px 0; display:flex;flex-direction:row; gap:48px; flex-wrap:wrap; padding: 0 48px">
    <div class="card" style="width: 18rem;">
        <img class="card-img-top" src="https://lirp.cdn-website.com/5d723f7de664428fab6c1e09200b20d1/dms3rep/multi/opt/709-376w.jpg" alt="Card image cap">
        <div class="card-body">
            <h2 class="card-title" style="font-weight: 700">Personal Trainer</h2>
            <br/>
            <br/>
            <a href="#" class="btn btn-primary">View More</a>
        </div>
    </div>
    <div class="card" style="width: 18rem;">
        <img class="card-img-top" src="https://lirp.cdn-website.com/5d723f7de664428fab6c1e09200b20d1/dms3rep/multi/opt/709-376w.jpg" alt="Card image cap">
        <div class="card-body">
            <h2 class="card-title" style="font-weight: 700">Ladies Trainer</h2>
            <br/>
            <br/>
            <a href="#" class="btn btn-primary">View More</a>
        </div>
    </div>
    <div class="card" style="width: 18rem;">
        <img class="card-img-top" src="https://lirp.cdn-website.com/5d723f7de664428fab6c1e09200b20d1/dms3rep/multi/opt/709-376w.jpg" alt="Card image cap">
        <div class="card-body">
            <h2 class="card-title" style="font-weight: 700">Personal Trainer</h2>
            <br/>
            <br/>
            <a href="#" class="btn btn-primary">View More</a>
        </div>
    </div>
    <div class="card" style="width: 18rem;">
        <img class="card-img-top" src="https://lirp.cdn-website.com/5d723f7de664428fab6c1e09200b20d1/dms3rep/multi/opt/709-376w.jpg" alt="Card image cap">
        <div class="card-body">
            <h2 class="card-title" style="font-weight: 700">Personal Trainer</h2>
            <br/>
            <br/>
            <a href="#" class="btn btn-primary">View More</a>
        </div>
    </div>
    <div class="card" style="width: 18rem;">
        <img class="card-img-top" src="https://lirp.cdn-website.com/5d723f7de664428fab6c1e09200b20d1/dms3rep/multi/opt/709-376w.jpg" alt="Card image cap">
        <div class="card-body">
            <h2 class="card-title" style="font-weight: 700">Personal Trainer</h2>
            <br/>
            <br/>
            <a href="#" class="btn btn-primary">View More</a>
        </div>
    </div>
    <div class="card" style="width: 18rem;">
        <img class="card-img-top" src="https://lirp.cdn-website.com/5d723f7de664428fab6c1e09200b20d1/dms3rep/multi/opt/709-376w.jpg" alt="Card image cap">
        <div class="card-body">
            <h2 class="card-title" style="font-weight: 700">Personal Trainer</h2>
            <br/>
            <br/>
            <a href="#" class="btn btn-primary">View More</a>
        </div>
    </div>
</div>