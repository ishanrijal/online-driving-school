<?php

use App\Http\Controllers\AdminController;
use Illuminate\Support\Facades\Route;

/* Common Resource Routes:
    index   - show all listings
    show    - show single listing
    create  - show form to create new listing
    store   - store new listings
    edit    - show form to edit new listings
    update  - update existing listings
    destroy - delete existing listings
*/
Route::get('/', function () {
    return view('home');
});
Route::get('login', [AdminController::class, 'login'] )->name('login');
Route::get('register', [AdminController::class, 'register'] )->name('register');
Route::get('admin/dashboard', [AdminController::class, 'dashboard'] )->name('admin.dashboard');